# setup_e_teste.py
"""Script completo para configurar e testar o projeto MCP"""

import os
import sys
import subprocess
import logging
import asyncio
from pathlib import Path

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def verificar_python():
    """Verifica se a versão do Python é adequada"""
    logger.info("🐍 Verificando versão do Python...")
    version = sys.version_info
    
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        logger.error("❌ Python 3.8+ é necessário")
        return False
    
    logger.info(f"✅ Python {version.major}.{version.minor}.{version.micro} - OK")
    return True

def instalar_dependencias():
    """Instala as dependências necessárias"""
    logger.info("📦 Instalando dependências...")
    
    # Lista de pacotes essenciais
    pacotes = [
        "fastmcp",
        "requests",
        "aiohttp",
        "pydantic",
        "python-dotenv"
    ]
    
    for pacote in pacotes:
        try:
            logger.info(f"📥 Instalando {pacote}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", pacote])
            logger.info(f"✅ {pacote} instalado com sucesso")
        except subprocess.CalledProcessError as e:
            logger.error(f"❌ Erro ao instalar {pacote}: {str(e)}")
            return False
    
    return True

def criar_estrutura_projeto():
    """Cria a estrutura de diretórios necessária"""
    logger.info("📁 Criando estrutura do projeto...")
    
    diretorios = [
        "mcp_server",
        "logs",
        "config"
    ]
    
    for diretorio in diretorios:
        Path(diretorio).mkdir(exist_ok=True)
        logger.info(f"✅ Diretório {diretorio}/ criado/verificado")
    
    # Criar __init__.py nos pacotes Python
    init_files = [
        "mcp_server/__init__.py"
    ]
    
    for init_file in init_files:
        Path(init_file).touch()
        logger.info(f"✅ Arquivo {init_file} criado/verificado")

def verificar_arquivos():
    """Verifica se todos os arquivos necessários existem"""
    logger.info("📋 Verificando arquivos do projeto...")
    
    arquivos_necessarios = [
        "wfs_decreto_tool.py",
        "mcp_server/server.py", 
        "main.py"
    ]
    
    arquivos_faltando = []
    
    for arquivo in arquivos_necessarios:
        if Path(arquivo).exists():
            logger.info(f"✅ {arquivo}")
        else:
            logger.error(f"❌ {arquivo} - NÃO ENCONTRADO")
            arquivos_faltando.append(arquivo)
    
    if arquivos_faltando:
        logger.error("❌ Arquivos faltando. Execute os artifacts do Claude para criá-los.")
        return False
    
    return True

def testar_imports():
    """Testa se todos os imports estão funcionando"""
    logger.info("🔧 Testando imports...")
    
    try:
        import fastmcp
        logger.info("✅ fastmcp importado com sucesso")
        
        import requests
        logger.info("✅ requests importado com sucesso")
        
        # Tentar importar nossas ferramentas
        sys.path.insert(0, os.getcwd())
        
        from wfs_decreto_tool import WFSDecretoTool, create_wfs_decreto_tool
        logger.info("✅ wfs_decreto_tool importado com sucesso")
        
        from mcp_server.server import create_mcp_server, list_registered_tools
        logger.info("✅ mcp_server.server importado com sucesso")
        
        return True
        
    except ImportError as e:
        logger.error(f"❌ Erro de import: {str(e)}")
        return False

async def testar_servidor():
    """Testa a criação e funcionamento do servidor"""
    logger.info("🚀 Testando servidor MCP com FastMCP 2.8.1...")
    
    try:
        # Importar módulos necessários
        from mcp_server.server import create_mcp_server, list_registered_tools
        
        # Criar servidor
        mcp = create_mcp_server()
        logger.info("✅ Servidor MCP criado com sucesso")
        
        # Debug da estrutura do FastMCP para entender como funciona
        logger.info("🔍 Analisando estrutura do FastMCP...")
        
        # Verificar atributos relacionados a ferramentas
        attrs = [attr for attr in dir(mcp) if 'tool' in attr.lower()]
        logger.info(f"📋 Atributos com 'tool': {attrs}")
        
        # Verificar se existe tools manager
        if hasattr(mcp, 'tools'):
            tools_manager = mcp.tools
            logger.info(f"🎯 Tools manager encontrado: {type(tools_manager)}")
            
            # Verificar métodos do tools manager
            if hasattr(tools_manager, '__dict__'):
                logger.info(f"📊 Tools manager conteúdo: {list(tools_manager.__dict__.keys())}")
        
        # Listar ferramentas usando nossa função
        tools = list_registered_tools(mcp)
        logger.info(f"✅ Ferramentas listadas: {len(tools)}")
        
        for tool_name, tool_info in tools.items():
            if tool_name != "error":
                logger.info(f"  🔧 {tool_name}: {tool_info.get('description', 'Sem descrição')}")
        
        # Testar chamada direta das funções (fallback)
        logger.info("🧪 Testando chamadas diretas das funções...")
        
        # Importar e testar função diretamente
        from wfs_decreto_tool import wfs_decreto_search, buscar_decretos_avancado
        
        # Teste 1
        result1 = await wfs_decreto_search("123", "2024", "teste")
        if result1.get('success'):
            logger.info("✅ wfs_decreto_search funcionando!")
            logger.info(f"📊 Resultado: {result1.get('data', {}).get('total_encontrados', 0)} registro(s)")
        else:
            logger.warning(f"⚠️  wfs_decreto_search com problemas: {result1.get('error')}")
        
        # Teste 2  
        result2 = await buscar_decretos_avancado("Salvador", "ORDINÁRIO", "2024-01-01", "2024-12-31")
        if result2.get('success'):
            logger.info("✅ buscar_decretos_avancado funcionando!")
            logger.info(f"📊 Resultado: {result2.get('data', {}).get('total_encontrados', 0)} registro(s)")
        else:
            logger.warning(f"⚠️  buscar_decretos_avancado com problemas: {result2.get('error')}")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro ao testar servidor: {str(e)}")
        import traceback
        logger.error(f"📍 Traceback: {traceback.format_exc()}")
        return False

def main():
    """Função principal do setup"""
    logger.info("🔧 SETUP E TESTE DO PROJETO MCP")
    logger.info("=" * 50)
    
    # Verificações iniciais
    if not verificar_python():
        return False
    
    # Criar estrutura
    criar_estrutura_projeto()
    
    # Instalar dependências
    if not instalar_dependencias():
        logger.error("❌ Falha na instalação de dependências")
        return False
    
    # Verificar arquivos
    if not verificar_arquivos():
        logger.error("❌ Arquivos necessários estão faltando")
        logger.info("💡 Execute os artifacts do Claude para criar os arquivos")
        return False
    
    # Testar imports
    if not testar_imports():
        logger.error("❌ Falha nos imports")
        return False
    
    # Testar servidor
    try:
        success = asyncio.run(testar_servidor())
        if not success:
            return False
    except Exception as e:
        logger.error(f"❌ Erro ao executar teste assíncrono: {str(e)}")
        return False
    
    # Sucesso!
    logger.info("\n" + "=" * 50)
    logger.info("🎉 SETUP CONCLUÍDO COM SUCESSO!")
    logger.info("✅ Projeto MCP está pronto para uso")
    logger.info("\n💡 Próximos passos:")
    logger.info("  1. Execute: python main.py")
    logger.info("  2. Teste as ferramentas")
    logger.info("  3. Configure URLs reais no wfs_decreto_tool.py")
    
    return True

if __name__ == "__main__":
    success = main()
    if not success:
        logger.error("\n❌ Setup falhou. Verifique os erros acima.")
        sys.exit(1)
    else:
        logger.info("\n🚀 Sistema pronto!")
        sys.exit(0)