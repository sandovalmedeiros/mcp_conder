# server.py
"""Servidor MCP para ferramentas de consulta WFS - FastMCP 2.8.1"""

from fastmcp import FastMCP
from typing import Any, Dict
import logging
import inspect

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Importar as funções de ferramenta
from wfs_decreto_tool import wfs_decreto_search, buscar_decretos_avancado

def create_mcp_server() -> FastMCP:
    """Cria e configura o servidor MCP com as ferramentas registradas"""
    
    logger.info("🚀 Criando servidor FastMCP 2.8.1...")
    
    try:
        # Criar instância do servidor FastMCP
        mcp = FastMCP("WFS Decreto Server")
        logger.info("✅ Servidor FastMCP criado com sucesso")
        
        # Registrar ferramentas
        _registrar_ferramentas(mcp)
        
        logger.info("🎉 Servidor MCP configurado com sucesso!")
        return mcp
        
    except Exception as e:
        logger.error(f"❌ Erro ao criar servidor MCP: {str(e)}")
        raise

def _registrar_ferramentas(mcp: FastMCP):
    """Registra as ferramentas no servidor MCP usando a API do FastMCP 2.8.1"""
    
    logger.info("🔧 Registrando ferramentas...")
    
    try:
        # Método 1: Tentar usar tool decorator/registration
        if hasattr(mcp, 'tool'):
            # Registrar ferramenta principal de busca de decretos
            mcp.tool(wfs_decreto_search)
            logger.info("✅ Ferramenta 'wfs_decreto_search' registrada via @tool")
            
            # Registrar ferramenta de busca avançada
            mcp.tool(buscar_decretos_avancado)
            logger.info("✅ Ferramenta 'buscar_decretos_avancado' registrada via @tool")
            
        # Método 2: Tentar registrar via add_tool se existir
        elif hasattr(mcp, 'add_tool'):
            mcp.add_tool(wfs_decreto_search)
            mcp.add_tool(buscar_decretos_avancado)
            logger.info("✅ Ferramentas registradas via add_tool")
            
        # Método 3: Tentar registrar via register_tool se existir
        elif hasattr(mcp, 'register_tool'):
            mcp.register_tool("wfs_decreto_search", wfs_decreto_search)
            mcp.register_tool("buscar_decretos_avancado", buscar_decretos_avancado)
            logger.info("✅ Ferramentas registradas via register_tool")
            
        else:
            # Listar métodos disponíveis para debug
            metodos = [m for m in dir(mcp) if not m.startswith('_')]
            logger.error(f"❌ Métodos de registro não encontrados. Métodos disponíveis: {metodos}")
            raise Exception("Nenhum método de registro de ferramenta encontrado")
            
    except Exception as e:
        logger.error(f"❌ Erro ao registrar ferramentas: {str(e)}")
        raise

def list_registered_tools(mcp: FastMCP) -> Dict[str, Any]:
    """Lista todas as ferramentas registradas no servidor"""
    tools = {}
    
    try:
        logger.info("📋 Listando ferramentas registradas...")
        
        # Método 1: Usar get_tools() se disponível
        if hasattr(mcp, 'get_tools'):
            try:
                tools_result = mcp.get_tools()
                logger.info(f"🔍 get_tools() retornou: {type(tools_result)} - {tools_result}")
                
                if isinstance(tools_result, dict):
                    for tool_name, tool_data in tools_result.items():
                        tools[tool_name] = {
                            "name": tool_name,
                            "description": f"Ferramenta {tool_name}",
                            "available": True,
                            "data": tool_data
                        }
                elif isinstance(tools_result, list):
                    for tool_item in tools_result:
                        if isinstance(tool_item, dict) and 'name' in tool_item:
                            tool_name = tool_item['name']
                            tools[tool_name] = {
                                "name": tool_name,
                                "description": tool_item.get('description', f"Ferramenta {tool_name}"),
                                "available": True,
                                "data": tool_item
                            }
                        elif isinstance(tool_item, str):
                            tools[tool_item] = {
                                "name": tool_item,
                                "description": f"Ferramenta {tool_item}",
                                "available": True
                            }
                
                logger.info(f"✅ Encontradas {len(tools)} ferramentas via get_tools()")
                
            except Exception as e:
                logger.warning(f"⚠️  get_tools() falhou: {str(e)}")
        
        # Método 2: Tentar via _tool_manager (API interna)
        if not tools and hasattr(mcp, '_tool_manager'):
            try:
                tool_manager = mcp._tool_manager
                logger.info(f"🎯 Tool manager encontrado: {type(tool_manager)}")
                
                if hasattr(tool_manager, 'tools'):
                    manager_tools = tool_manager.tools
                    if isinstance(manager_tools, dict):
                        for tool_name, tool_obj in manager_tools.items():
                            tools[tool_name] = {
                                "name": tool_name,
                                "description": f"Ferramenta {tool_name}",
                                "available": True,
                                "type": str(type(tool_obj))
                            }
                        logger.info(f"✅ Encontradas {len(tools)} ferramentas via _tool_manager")
                        
            except Exception as e:
                logger.warning(f"⚠️  _tool_manager falhou: {str(e)}")
        
        # Método 3: Tentar métodos específicos conhecidos
        if not tools:
            known_methods = ['list_tools', '_mcp_list_tools']
            for method_name in known_methods:
                if hasattr(mcp, method_name):
                    try:
                        method = getattr(mcp, method_name)
                        result = method()
                        logger.info(f"🔍 {method_name}() retornou: {result}")
                        
                        if isinstance(result, list):
                            for tool_name in result:
                                if isinstance(tool_name, str):
                                    tools[tool_name] = {
                                        "name": tool_name,
                                        "description": f"Ferramenta {tool_name}",
                                        "available": True,
                                        "source": method_name
                                    }
                        elif isinstance(result, dict):
                            tools.update(result)
                            
                        if tools:
                            logger.info(f"✅ Encontradas {len(tools)} ferramentas via {method_name}")
                            break
                            
                    except Exception as e:
                        logger.warning(f"⚠️  {method_name}() falhou: {str(e)}")
        
        # Se ainda não encontrou ferramentas, usar informações estáticas
        if not tools:
            logger.warning("⚠️  Nenhum método automático funcionou, usando informações estáticas")
            tools = {
                "wfs_decreto_search": {
                    "name": "wfs_decreto_search",
                    "description": "Consulta decretos municipais via serviço WFS",
                    "available": True,
                    "status": "Registrada via @tool"
                },
                "buscar_decretos_avancado": {
                    "name": "buscar_decretos_avancado", 
                    "description": "Busca avançada de decretos com múltiplos filtros",
                    "available": True,
                    "status": "Registrada via @tool"
                }
            }
            logger.info(f"📝 Usando informações estáticas: {len(tools)} ferramentas")
        
        logger.info(f"📊 Total de ferramentas listadas: {len(tools)}")
        
    except Exception as e:
        logger.error(f"❌ Erro ao listar ferramentas: {str(e)}")
        # Retornar estrutura padrão em caso de erro
        tools = {
            "error": {
                "name": "error",
                "description": f"Erro ao listar ferramentas: {str(e)}",
                "available": False
            }
        }
    
    return tools

def test_tool_registration(mcp: FastMCP) -> bool:
    """Testa se as ferramentas foram registradas corretamente"""
    
    logger.info("🧪 Testando registro de ferramentas...")
    
    try:
        # Verificar se o servidor tem ferramentas registradas
        tools_info = list_registered_tools(mcp)
        
        if not isinstance(tools_info, dict):
            logger.error(f"❌ Formato inválido retornado: {type(tools_info)}")
            return False
            
        if "error" in tools_info and len(tools_info) == 1:
            logger.error(f"❌ Erro na listagem: {tools_info['error']['description']}")
            return False
            
        # Filtrar itens de erro
        valid_tools = {k: v for k, v in tools_info.items() if k != "error"}
        
        if len(valid_tools) == 0:
            logger.error("❌ Nenhuma ferramenta registrada encontrada")
            return False
            
        logger.info(f"✅ {len(valid_tools)} ferramenta(s) registrada(s) com sucesso:")
        for tool_name, tool_info in valid_tools.items():
            if isinstance(tool_info, dict):
                status = tool_info.get('status', 'OK')
                logger.info(f"  🔧 {tool_name} - {status}")
            else:
                logger.info(f"  🔧 {tool_name}")
            
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro no teste de registro: {str(e)}")
        return False

def debug_fastmcp_structure(mcp: FastMCP):
    """Debug: mostra a estrutura interna do FastMCP para entender como funciona"""
    
    logger.info("🔍 DEBUG: Estrutura interna do FastMCP")
    logger.info("-" * 40)
    
    # Listar todos os atributos não privados
    attrs = [attr for attr in dir(mcp) if not attr.startswith('_')]
    logger.info(f"📋 Atributos públicos: {attrs}")
    
    # Verificar atributos específicos relacionados a ferramentas
    tool_attrs = [attr for attr in attrs if 'tool' in attr.lower()]
    if tool_attrs:
        logger.info(f"🔧 Atributos relacionados a ferramentas: {tool_attrs}")
        
        for attr in tool_attrs:
            try:
                value = getattr(mcp, attr)
                attr_type = type(value).__name__
                logger.info(f"  {attr}: {attr_type}")
                
                # Se for um objeto, listar seus métodos
                if hasattr(value, '__dict__') or hasattr(value, '__dir__'):
                    methods = [m for m in dir(value) if not m.startswith('_')]
                    if methods:
                        logger.info(f"    Métodos: {methods[:5]}...")  # Mostrar só os primeiros 5
                        
            except Exception as e:
                logger.warning(f"  {attr}: Erro ao acessar - {str(e)}")
    
    # Verificar se existe um manager de ferramentas
    if hasattr(mcp, 'tools'):
        logger.info("🎯 Encontrado gerenciador de ferramentas!")
        tools_manager = mcp.tools
        
        if hasattr(tools_manager, '__dict__'):
            logger.info(f"📊 Conteúdo do tools manager: {list(tools_manager.__dict__.keys())}")
            
        if hasattr(tools_manager, 'tools'):
            logger.info(f"🗂️  Ferramentas no manager: {list(tools_manager.tools.keys())}")
            
    logger.info("-" * 40)