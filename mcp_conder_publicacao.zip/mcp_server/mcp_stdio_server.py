# mcp_stdio_server.py
"""Servidor MCP usando STDIO para integração com Claude Desktop"""

import asyncio
import logging
import sys
from pathlib import Path

# Adicionar path para imports
sys.path.insert(0, str(Path(__file__).parent))

from fastmcp import FastMCP
from wfs_decreto_tool import wfs_decreto_search, buscar_decretos_avancado

# Configurar logging para arquivo (não interferir com STDIO)
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('mcp_stdio.log'),
        # Não usar StreamHandler para não interferir com STDIO
    ]
)
logger = logging.getLogger(__name__)

def create_mcp_stdio_server():
    """Cria servidor MCP para comunicação STDIO com Claude Desktop"""
    
    logger.info("🚀 Criando servidor MCP STDIO...")
    
    # Criar servidor FastMCP
    mcp = FastMCP("WFS Decreto Server")
    
    # Registrar ferramentas usando decorator @tool
    @mcp.tool
    async def consultar_decreto(numero_decreto: str, ano: str = "", assunto: str = "") -> dict:
        """
        Consulta um decreto específico por número.
        
        Args:
            numero_decreto: Número do decreto a ser consultado
            ano: Ano do decreto (opcional)
            assunto: Assunto/tema do decreto (opcional)
        
        Returns:
            Dicionário com informações do decreto encontrado
        """
        logger.info(f"📋 Claude solicitou consulta: decreto {numero_decreto}, ano {ano}")
        result = await wfs_decreto_search(numero_decreto, ano, assunto)
        logger.info(f"📊 Resultado: {result.get('data', {}).get('total_encontrados', 0)} decreto(s)")
        return result
    
    @mcp.tool
    async def buscar_decretos_municipio(municipio: str, tipo_decreto: str = "", data_inicio: str = "", data_fim: str = "") -> dict:
        """
        Busca decretos por município com filtros opcionais.
        
        Args:
            municipio: Nome do município
            tipo_decreto: Tipo de decreto (ORDINÁRIO, COMPLEMENTAR, etc.)
            data_inicio: Data inicial da busca (YYYY-MM-DD)
            data_fim: Data final da busca (YYYY-MM-DD)
        
        Returns:
            Dicionário com lista de decretos encontrados
        """
        logger.info(f"🏙️ Claude solicitou busca: {municipio}, tipo {tipo_decreto}")
        result = await buscar_decretos_avancado(municipio, tipo_decreto, data_inicio, data_fim)
        logger.info(f"📊 Resultado: {result.get('data', {}).get('total_encontrados', 0)} decreto(s)")
        return result
    
    logger.info("✅ Ferramentas registradas para Claude Desktop")
    return mcp

async def main():
    """Função principal para executar servidor STDIO"""
    try:
        logger.info("🎬 Iniciando servidor MCP STDIO para Claude Desktop...")
        
        # Criar servidor
        mcp = create_mcp_stdio_server()
        
        # Executar servidor em modo STDIO
        logger.info("🔌 Iniciando comunicação STDIO com Claude Desktop...")
        await mcp.run_stdio_async()
        
    except Exception as e:
        logger.error(f"❌ Erro no servidor STDIO: {str(e)}")
        raise

if __name__ == "__main__":
    # Executar servidor STDIO
    asyncio.run(main())
