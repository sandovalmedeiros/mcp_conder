# mcp_http_server.py
"""Servidor MCP HTTP para integração com Claude.ai via webhooks/API"""

import asyncio
import logging
import sys
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, Any, Optional
import uvicorn

# Adicionar path para imports
sys.path.insert(0, str(Path(__file__).parent))

from fastmcp import FastMCP
from wfs_decreto_tool import wfs_decreto_search, buscar_decretos_avancado

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Modelos Pydantic para API
class DecretoSearchRequest(BaseModel):
    numero_decreto: str
    ano: Optional[str] = ""
    assunto: Optional[str] = ""

class BuscaAvancadaRequest(BaseModel):
    municipio: str
    tipo_decreto: Optional[str] = ""
    data_inicio: Optional[str] = ""
    data_fim: Optional[str] = ""

class MCPToolCall(BaseModel):
    tool_name: str
    parameters: Dict[str, Any]

# Criar aplicação FastAPI
app = FastAPI(
    title="WFS Decreto MCP Server",
    description="Servidor MCP para consulta de decretos municipais via WFS",
    version="1.0.0"
)

# Configurar CORS para permitir chamadas do Claude.ai
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, especificar domínios do Claude
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Criar servidor MCP
mcp_server = None

@app.on_event("startup")
async def startup_event():
    """Inicializa o servidor MCP quando a API inicia"""
    global mcp_server
    logger.info("🚀 Inicializando servidor MCP HTTP...")
    
    mcp_server = FastMCP("WFS Decreto HTTP Server")
    
    # Registrar ferramentas
    @mcp_server.tool
    async def consultar_decreto_http(numero_decreto: str, ano: str = "", assunto: str = "") -> dict:
        """Consulta decreto específico via HTTP"""
        return await wfs_decreto_search(numero_decreto, ano, assunto)
    
    @mcp_server.tool  
    async def buscar_decretos_http(municipio: str, tipo_decreto: str = "", data_inicio: str = "", data_fim: str = "") -> dict:
        """Busca decretos por município via HTTP"""
        return await buscar_decretos_avancado(municipio, tipo_decreto, data_inicio, data_fim)
    
    logger.info("✅ Servidor MCP HTTP inicializado")

# Endpoints da API

@app.get("/")
async def root():
    """Endpoint raiz com informações do servidor"""
    return {
        "service": "WFS Decreto MCP Server",
        "status": "running",
        "version": "1.0.0",
        "tools": [
            "consultar_decreto",
            "buscar_decretos_avancado"
        ]
    }

@app.get("/health")
async def health_check():
    """Endpoint de health check"""
    return {"status": "healthy", "server": "mcp-wfs-decreto"}

@app.post("/tools/consultar_decreto")
async def consultar_decreto_endpoint(request: DecretoSearchRequest):
    """
    Endpoint para consultar decreto específico
    
    Exemplo de uso:
    POST /tools/consultar_decreto
    {
        "numero_decreto": "12345",
        "ano": "2024",
        "assunto": "trânsito"
    }
    """
    try:
        logger.info(f"📋 Recebida consulta via HTTP: {request.numero_decreto}")
        
        result = await wfs_decreto_search(
            request.numero_decreto, 
            request.ano, 
            request.assunto
        )
        
        logger.info(f"📊 Retornando resultado: {result.get('data', {}).get('total_encontrados', 0)} decreto(s)")
        return result
        
    except Exception as e:
        logger.error(f"❌ Erro na consulta: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/tools/buscar_decretos_avancado")
async def buscar_decretos_endpoint(request: BuscaAvancadaRequest):
    """
    Endpoint para busca avançada de decretos
    
    Exemplo de uso:
    POST /tools/buscar_decretos_avancado
    {
        "municipio": "Salvador",
        "tipo_decreto": "ORDINÁRIO",
        "data_inicio": "2024-01-01",
        "data_fim": "2024-12-31"
    }
    """
    try:
        logger.info(f"🏙️ Recebida busca avançada via HTTP: {request.municipio}")
        
        result = await buscar_decretos_avancado(
            request.municipio,
            request.tipo_decreto,
            request.data_inicio,
            request.data_fim
        )
        
        logger.info(f"📊 Retornando 