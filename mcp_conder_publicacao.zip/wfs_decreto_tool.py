# wfs_decreto_tool.py
"""Ferramenta FINAL para consultar decretos via WFS do CONDER-BA"""

import requests
import json
import logging
import xml.etree.ElementTree as ET
from typing import Any, Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)

async def wfs_decreto_search(numero_decreto: str, ano: str = "", assunto: str = "") -> Dict[str, Any]:
    """
    Consulta decretos municipais via serviço WFS do CONDER
    
    Args:
        numero_decreto: Número do decreto a ser consultado
        ano: Ano do decreto (opcional)
        assunto: Assunto/tema do decreto (opcional)
    
    Returns:
        Dicionário com os resultados da consulta
    """
    try:
        logger.info(f"🔍 Consultando CONDER: decreto {numero_decreto}, ano: {ano}")
        
        result = await _consultar_wfs_conder(numero_decreto, ano, assunto)
        
        return {
            "success": True,
            "data": result,
            "message": f"Consulta realizada no CONDER para decreto {numero_decreto}"
        }
        
    except Exception as e:
        logger.error(f"❌ Erro na consulta WFS CONDER: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "message": "Erro ao consultar serviço WFS do CONDER"
        }

async def buscar_decretos_avancado(
    municipio: str = "",
    tipo_decreto: str = "",
    data_inicio: str = "",
    data_fim: str = ""
) -> Dict[str, Any]:
    """
    Busca avançada de decretos com múltiplos filtros no CONDER
    
    Args:
        municipio: Nome do município
        tipo_decreto: Tipo de decreto (ex: "DESAPROPRIAÇÃO", "ORDINÁRIO")
        data_inicio: Data inicial no formato YYYY-MM-DD
        data_fim: Data final no formato YYYY-MM-DD
    
    Returns:
        Dicionário com os resultados da busca
    """
    try:
        logger.info(f"🔍 Busca avançada CONDER - Município: {municipio}, Tipo: {tipo_decreto}")
        
        result = await _buscar_wfs_conder_avancado(municipio, tipo_decreto, data_inicio, data_fim)
        
        return {
            "success": True,
            "data": result,
            "message": f"Busca avançada concluída no CONDER - {result.get('total_encontrados', 0)} decretos encontrados"
        }
        
    except Exception as e:
        logger.error(f"❌ Erro na busca avançada CONDER: {str(e)}")
        return {
            "success": False,
            "error": str(e),
            "message": "Erro ao realizar busca avançada no CONDER"
        }

async def _consultar_wfs_conder(numero: str, ano: str = "", assunto: str = "") -> Dict[str, Any]:
    """Realiza a consulta ao serviço WFS do CONDER usando a estrutura descoberta"""
    
    # URL e layer corretos baseados na descoberta
    base_url = "https://mapas.conder.ba.gov.br/arcgis/services/Decretos/Decretos/MapServer/WFSServer"
    type_name = "Decretos:Decretos_da_Bahia"
    
    # Construir filtro CQL usando os nomes reais dos campos
    filtros = []
    
    if numero:
        filtros.append(f"N__do_Decreto='{numero}'")
    
    if ano:
        filtros.append(f"Ano_do_Decreto='{ano}'")
    
    if assunto:
        filtros.append(f"Descricao LIKE '%{assunto}%'")
    
    cql_filter = " AND ".join(filtros) if filtros else "1=1"
    
    # Parâmetros da consulta WFS
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "GetFeature",
        "typeName": type_name,
        "outputFormat": "GML3",
        "maxFeatures": 100
    }
    
    if filtros:
        params["CQL_FILTER"] = cql_filter
    
    try:
        logger.info(f"🌐 Consultando CONDER: {base_url}")
        logger.info(f"🔍 Filtro: {cql_filter}")
        
        response = requests.get(base_url, params=params, timeout=30)
        
        if response.status_code != 200:
            raise Exception(f"Erro HTTP {response.status_code}: {response.text}")
        
        # Processar resposta GML
        root = ET.fromstring(response.text)
        
        # Namespace GML
        namespaces = {
            'wfs': 'http://www.opengis.net/wfs/2.0',
            'gml': 'http://www.opengis.net/gml',
            'esri': 'http://www.esri.com/wfs'
        }
        
        # Extrair features
        features = []
        
        # Procurar por elementos de feature
        for elem in root.iter():
            if 'Decretos_da_Bahia' in str(elem.tag):
                # Encontrou um feature, extrair propriedades
                properties = {}
                
                for child in elem:
                    tag_name = child.tag.split('}')[-1]  # Remove namespace
                    if child.text and tag_name not in ['SHAPE', 'boundedBy']:
                        properties[tag_name] = child.text.strip()
                
                if properties:
                    features.append({
                        "properties": properties,
                        "geometry": None  # Geometria não é necessária para esta consulta
                    })
        
        # Montar resultado
        result = {
            "total_encontrados": len(features),
            "decretos": [],
            "fonte": "CONDER-BA WFS",
            "url_consultada": base_url,
            "filtro_aplicado": cql_filter
        }
        
        for feature in features:
            properties = feature.get("properties", {})
            
            # Mapear para estrutura padronizada usando nomes reais dos campos
            decreto_info = {
                "numero": properties.get("N__do_Decreto"),
                "ano": properties.get("Ano_do_Decreto"),
                "data_publicacao": _formatar_data(properties.get("Data")),
                "descricao": properties.get("Descricao"),
                "municipio": properties.get("Municipio"),
                "observacao": properties.get("Observacao"),
                "instituicao": properties.get("Instituicao"),
                "instituicao_extenso": properties.get("Inst_Extenso"),
                "sro": properties.get("SRO"),
                "identificacao": properties.get("Identificacao"),
                "observacao_espacial": properties.get("Obs_Espacial"),
                "object_id": properties.get("OBJECTID"),
                # Campos derivados
                "tipo": _extrair_tipo_decreto(properties.get("Descricao", "")),
                "eh_desapropriacao": _eh_decreto_desapropriacao(properties.get("Descricao", "")),
                "status": "ATIVO"
            }
            
            result["decretos"].append(decreto_info)
        
        logger.info(f"✅ Consulta CONDER realizada: {len(features)} decreto(s) encontrado(s)")
        return result
        
    except Exception as e:
        logger.error(f"❌ Erro na consulta CONDER: {str(e)}")
        raise

async def _buscar_wfs_conder_avancado(
    municipio: str = "",
    tipo_decreto: str = "",
    data_inicio: str = "",
    data_fim: str = ""
) -> Dict[str, Any]:
    """Realiza busca avançada no WFS do CONDER"""
    
    base_url = "https://mapas.conder.ba.gov.br/arcgis/services/Decretos/Decretos/MapServer/WFSServer"
    type_name = "Decretos:Decretos_da_Bahia"
    
    # Construir filtros usando nomes reais dos campos
    filtros = []
    
    if municipio:
        # Buscar por município (aceita nomes parciais)
        filtros.append(f"Municipio LIKE '%{municipio}%'")
    
    if tipo_decreto:
        # Para desapropriação, buscar na descrição
        if "DESAPROPRIA" in tipo_decreto.upper():
            filtros.append(f"Descricao LIKE '%desapropria%'")
        else:
            filtros.append(f"Descricao LIKE '%{tipo_decreto}%'")
    
    # Filtros de data baseados no ano
    if data_inicio:
        ano_inicio = data_inicio[:4]
        filtros.append(f"Ano_do_Decreto >= '{ano_inicio}'")
    
    if data_fim:
        ano_fim = data_fim[:4]
        filtros.append(f"Ano_do_Decreto <= '{ano_fim}'")
    
    cql_filter = " AND ".join(filtros) if filtros else "1=1"
    
    # Parâmetros da consulta
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "GetFeature",
        "typeName": type_name,
        "outputFormat": "GML3",
        "maxFeatures": 500
    }
    
    if filtros:
        params["CQL_FILTER"] = cql_filter
    
    try:
        logger.info(f"🌐 Busca avançada CONDER: {cql_filter}")
        
        response = requests.get(base_url, params=params, timeout=60)
        
        if response.status_code != 200:
            raise Exception(f"Erro HTTP {response.status_code}: {response.text}")
        
        # Processar resposta similar ao método anterior
        root = ET.fromstring(response.text)
        
        features = []
        for elem in root.iter():
            if 'Decretos_da_Bahia' in str(elem.tag):
                properties = {}
                for child in elem:
                    tag_name = child.tag.split('}')[-1]
                    if child.text and tag_name not in ['SHAPE', 'boundedBy']:
                        properties[tag_name] = child.text.strip()
                
                if properties:
                    features.append({"properties": properties})
        
        # Processar resultados
        decretos_processados = []
        
        for feature in features:
            properties = feature.get("properties", {})
            
            decreto_info = {
                "numero": properties.get("N__do_Decreto"),
                "ano": properties.get("Ano_do_Decreto"),
                "data_publicacao": _formatar_data(properties.get("Data")),
                "descricao": properties.get("Descricao"),
                "municipio": properties.get("Municipio"),
                "observacao": properties.get("Observacao"),
                "instituicao": properties.get("Instituicao"),
                "tipo": _extrair_tipo_decreto(properties.get("Descricao", "")),
                "eh_desapropriacao": _eh_decreto_desapropriacao(properties.get("Descricao", ""))
            }
            
            decretos_processados.append(decreto_info)
        
        result = {
            "total_encontrados": len(decretos_processados),
            "decretos": decretos_processados,
            "parametros_busca": {
                "municipio": municipio,
                "tipo_decreto": tipo_decreto,
                "data_inicio": data_inicio,
                "data_fim": data_fim
            },
            "fonte": "CONDER-BA WFS",
            "filtro_aplicado": cql_filter
        }
        
        logger.info(f"✅ Busca avançada CONDER: {len(decretos_processados)} decreto(s)")
        return result
        
    except Exception as e:
        logger.error(f"❌ Erro na busca avançada CONDER: {str(e)}")
        raise

def _formatar_data(data_str: str) -> str:
    """Formata data do formato ISO para formato brasileiro"""
    if not data_str:
        return ""
    
    try:
        # Parse da data ISO (2023-01-16T00:00:00)
        dt = datetime.fromisoformat(data_str.replace('T', ' ').replace('Z', ''))
        return dt.strftime("%d/%m/%Y")
    except:
        return data_str

def _extrair_tipo_decreto(descricao: str) -> str:
    """Extrai o tipo de decreto baseado na descrição"""
    if not descricao:
        return "INDETERMINADO"
    
    descricao_upper = descricao.upper()
    
    if "DESAPROPRIA" in descricao_upper:
        return "DESAPROPRIAÇÃO"
    elif "UTILIDADE PÚBLICA" in descricao_upper:
        return "UTILIDADE PÚBLICA"
    elif "COMPLEMENTAR" in descricao_upper:
        return "COMPLEMENTAR"
    elif "ORDINÁRIO" in descricao_upper or "ORDINARIO" in descricao_upper:
        return "ORDINÁRIO"
    else:
        return "REGULAMENTAÇÃO"

def _eh_decreto_desapropriacao(descricao: str) -> bool:
    """Verifica se é um decreto de desapropriação"""
    if not descricao:
        return False
    
    palavras_chave = [
        "desapropriação", "desapropriacao", "desapropria",
        "utilidade pública", "interesse social",
        "declarada de utilidade", "fins de desapropriação"
    ]
    
    descricao_lower = descricao.lower()
    return any(palavra in descricao_lower for palavra in palavras_chave)

# Função de teste
async def testar_decreto_desapropriacao():
    """Testa especificamente decretos de desapropriação"""
    
    logger.info("🧪 Testando busca por decretos de desapropriação...")
    
    # Buscar decretos de desapropriação de 2018-2022
    result = await buscar_decretos_avancado(
        municipio="",
        tipo_decreto="DESAPROPRIAÇÃO", 
        data_inicio="2018-01-01",
        data_fim="2022-12-31"
    )
    
    if result.get("success"):
        decretos = result["data"]["decretos"]
        desapropriacoes = [d for d in decretos if d.get("eh_desapropriacao")]
        
        logger.info(f"📊 Total de decretos: {len(decretos)}")
        logger.info(f"📊 Decretos de desapropriação: {len(desapropriacoes)}")
        
        # Agrupar por município
        municipios = {}
        for decreto in desapropriacoes:
            mun = decreto.get("municipio", "Não informado")
            if mun not in municipios:
                municipios[mun] = 0
            municipios[mun] += 1
        
        logger.info("📋 Decretos de desapropriação por município:")
        for mun, count in sorted(municipios.items()):
            logger.info(f"  • {mun}: {count} decreto(s)")
    
    return result
