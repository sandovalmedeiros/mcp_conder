# verificar_fastmcp.py
"""Script para verificar a estrutura real do FastMCP instalado"""

import fastmcp
import inspect
import pkgutil
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def explorar_modulo(modulo, nome_modulo="", nivel=0):
    """Explora recursivamente um módulo e seus submódulos"""
    indent = "  " * nivel
    
    try:
        # Listar atributos do módulo
        atributos = dir(modulo)
        classes = []
        funcoes = []
        submodulos = []
        
        for attr_name in atributos:
            if not attr_name.startswith('_'):
                try:
                    attr = getattr(modulo, attr_name)
                    if inspect.isclass(attr):
                        classes.append(attr_name)
                    elif inspect.isfunction(attr):
                        funcoes.append(attr_name)
                    elif inspect.ismodule(attr):
                        submodulos.append(attr_name)
                except:
                    pass
        
        if classes:
            logger.info(f"{indent}📦 {nome_modulo} - Classes: {', '.join(classes)}")
        if funcoes:
            logger.info(f"{indent}🔧 {nome_modulo} - Funções: {', '.join(funcoes)}")
        if submodulos:
            logger.info(f"{indent}📁 {nome_modulo} - Submódulos: {', '.join(submodulos)}")
            
        # Explorar submódulos se o nível não for muito profundo
        if nivel < 2:
            for submod_name in submodulos:
                try:
                    submod = getattr(modulo, submod_name)
                    explorar_modulo(submod, f"{nome_modulo}.{submod_name}", nivel + 1)
                except:
                    pass
                    
    except Exception as e:
        logger.error(f"{indent}❌ Erro ao explorar {nome_modulo}: {str(e)}")

def verificar_fastmcp():
    """Verifica a estrutura do FastMCP instalado"""
    logger.info("🔍 Verificando estrutura do FastMCP...")
    logger.info("=" * 60)
    
    # Informações básicas
    logger.info(f"📍 Localização: {fastmcp.__file__}")
    logger.info(f"📋 Versão: {getattr(fastmcp, '__version__', 'Desconhecida')}")
    logger.info(f"📝 Documentação: {getattr(fastmcp, '__doc__', 'Não disponível')}")
    
    logger.info("\n📦 Explorando módulos disponíveis:")
    logger.info("-" * 40)
    
    # Explorar módulo principal
    explorar_modulo(fastmcp, "fastmcp")
    
    # Tentar encontrar submódulos usando pkgutil
    logger.info("\n🔍 Procurando submódulos com pkgutil:")
    try:
        if hasattr(fastmcp, '__path__'):
            for importer, modname, ispkg in pkgutil.iter_modules(fastmcp.__path__, prefix='fastmcp.'):
                logger.info(f"  📁 {modname} (pacote: {ispkg})")
    except Exception as e:
        logger.error(f"Erro ao listar submódulos: {str(e)}")
    
    # Verificar se existem classes/interfaces específicas que procuramos
    logger.info("\n🎯 Procurando classes/interfaces específicas:")
    classes_procuradas = [
        'FastMCP', 'MCP', 'Server', 'Tool', 'BaseTool', 
        'ToolDefinition', 'ToolInput', 'ToolOutput', 'ToolMetadata'
    ]
    
    for classe in classes_procuradas:
        if hasattr(fastmcp, classe):
            obj = getattr(fastmcp, classe)
            tipo = "Classe" if inspect.isclass(obj) else "Função" if inspect.isfunction(obj) else "Outro"
            logger.info(f"  ✅ {classe} ({tipo})")
        else:
            logger.info(f"  ❌ {classe} não encontrada")

def gerar_exemplo_uso():
    """Gera exemplo de uso baseado na estrutura encontrada"""
    logger.info("\n💡 Exemplos de uso baseados na estrutura encontrada:")
    logger.info("-" * 50)
    
    # Verificar se FastMCP existe
    if hasattr(fastmcp, 'FastMCP'):
        logger.info("✅ Exemplo usando FastMCP:")
        logger.info("   from fastmcp import FastMCP")
        logger.info("   mcp = FastMCP('nome_do_servidor')")
    
    # Verificar outras possibilidades
    classes_disponiveis = [attr for attr in dir(fastmcp) 
                          if not attr.startswith('_') and inspect.isclass(getattr(fastmcp, attr))]
    
    if classes_disponiveis:
        logger.info(f"\n📝 Classes disponíveis para uso: {', '.join(classes_disponiveis)}")

def main():
    """Função principal"""
    try:
        verificar_fastmcp()
        gerar_exemplo_uso()
        
        logger.info("\n" + "=" * 60)
        logger.info("✅ Verificação concluída!")
        logger.info("💡 Use as informações acima para ajustar seus imports e código.")
        
    except Exception as e:
        logger.error(f"❌ Erro durante verificação: {str(e)}")

if __name__ == "__main__":
    main()