# testar_conder_real.py
"""Teste real da conexão com WFS do CONDER"""

import asyncio
import requests
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def testar_conder_completo():
    """Teste completo do serviço WFS do CONDER"""
    
    logger.info("🚀 TESTE COMPLETO - WFS CONDER")
    logger.info("=" * 50)
    
    base_url = "https://mapas.conder.ba.gov.br/arcgis/services/Decretos/Decretos/MapServer/WFSServer"
    
    # Teste 1: GetCapabilities
    logger.info("📋 Teste 1: GetCapabilities")
    await testar_capabilities(base_url)
    
    # Teste 2: Listar FeatureTypes
    logger.info("\n📋 Teste 2: DescribeFeatureType")
    await testar_feature_types(base_url)
    
    # Teste 3: GetFeature simples
    logger.info("\n📋 Teste 3: GetFeature (busca geral)")
    await testar_get_feature_simples(base_url)
    
    # Teste 4: GetFeature com filtro específico
    logger.info("\n📋 Teste 4: GetFeature com filtros")
    await testar_get_feature_filtrado(base_url)

async def testar_capabilities(base_url):
    """Testa GetCapabilities"""
    params = {
        "service": "WFS",
        "version": "2.0.0", 
        "request": "GetCapabilities"
    }
    
    try:
        response = requests.get(base_url, params=params, timeout=30)
        logger.info(f"📡 Status: {response.status_code}")
        logger.info(f"📄 Content-Type: {response.headers.get('content-type', 'N/A')}")
        logger.info(f"📏 Tamanho: {len(response.text)} caracteres")
        
        if response.status_code == 200:
            # Procurar por FeatureType names
            if "FeatureType" in response.text:
                logger.info("✅ Capabilities obtido com sucesso")
                # Extrair nomes dos FeatureTypes
                import re
                feature_types = re.findall(r'<Name>(.*?)</Name>', response.text)
                if feature_types:
                    logger.info(f"🔍 FeatureTypes encontrados: {feature_types}")
                else:
                    logger.info("⚠️  Nenhum FeatureType encontrado no XML")
            else:
                logger.warning("⚠️  Resposta não contém informações de FeatureType")
        else:
            logger.error(f"❌ Erro: {response.status_code}")
            logger.error(f"📄 Resposta: {response.text[:500]}")
            
    except Exception as e:
        logger.error(f"❌ Erro no GetCapabilities: {str(e)}")

async def testar_feature_types(base_url):
    """Testa DescribeFeatureType"""
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "DescribeFeatureType"
    }
    
    try:
        response = requests.get(base_url, params=params, timeout=30)
        logger.info(f"📡 Status: {response.status_code}")
        
        if response.status_code == 200:
            logger.info("✅ DescribeFeatureType obtido")
            # Procurar por nomes de campos
            if "element name" in response.text:
                import re
                campos = re.findall(r'element name="(.*?)"', response.text)
                if campos:
                    logger.info(f"📋 Campos encontrados: {campos[:10]}...")  # Primeiros 10
                else:
                    logger.info("⚠️  Nenhum campo encontrado")
        else:
            logger.error(f"❌ Erro: {response.status_code}")
            
    except Exception as e:
        logger.error(f"❌ Erro no DescribeFeatureType: {str(e)}")

async def testar_get_feature_simples(base_url):
    """Testa GetFeature simples"""
    
    # Tentar diferentes nomes de layer
    possible_layers = [
        "Decretos:Decretos",
        "Decretos",
        "DECRETOS",
        "decretos",
        "MapServer_0",
        "0"
    ]
    
    for layer_name in possible_layers:
        logger.info(f"🔍 Testando layer: {layer_name}")
        
        params = {
            "service": "WFS",
            "version": "2.0.0",
            "request": "GetFeature",
            "typeName": layer_name,
            "outputFormat": "application/json",
            "maxFeatures": 5
        }
        
        try:
            response = requests.get(base_url, params=params, timeout=30)
            logger.info(f"  📡 Status: {response.status_code}")
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    features = data.get("features", [])
                    logger.info(f"  ✅ Sucesso! {len(features)} features encontradas")
                    
                    if features:
                        # Mostrar estrutura do primeiro feature
                        first_feature = features[0]
                        properties = first_feature.get("properties", {})
                        logger.info(f"  📋 Campos disponíveis: {list(properties.keys())}")
                        return layer_name, data  # Retorna o layer que funcionou
                        
                except Exception as json_error:
                    logger.warning(f"  ⚠️  Resposta não é JSON válido: {str(json_error)}")
                    logger.info(f"  📄 Primeiros 200 chars: {response.text[:200]}")
            else:
                logger.warning(f"  ❌ Erro {response.status_code}")
                
        except Exception as e:
            logger.warning(f"  ❌ Erro na requisição: {str(e)}")
    
    logger.error("❌ Nenhum layer funcionou")
    return None, None

async def testar_get_feature_filtrado(base_url):
    """Testa GetFeature com filtros para decretos de desapropriação"""
    
    # Usar layer que funcionou no teste anterior
    layer_name = "Decretos:Decretos"  # Assumindo que este é o correto
    
    # Filtros para decretos de desapropriação
    filtros_teste = [
        "TIPO LIKE '%DESAPROPRIA%'",
        "ASSUNTO LIKE '%desapropria%'",
        "EMENTA LIKE '%desapropria%'",
        "ANO >= '2018' AND ANO <= '2022'",
        "MUNICIPIO IN ('Salvador', 'Barreiras', 'Lauro de Freitas')"
    ]
    
    for filtro in filtros_teste:
        logger.info(f"🔍 Testando filtro: {filtro}")
        
        params = {
            "service": "WFS",
            "version": "2.0.0",
            "request": "GetFeature",
            "typeName": layer_name,
            "outputFormat": "application/json",
            "CQL_FILTER": filtro,
            "maxFeatures": 10
        }
        
        try:
            response = requests.get(base_url, params=params, timeout=30)
            logger.info(f"  📡 Status: {response.status_code}")
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    features = data.get("features", [])
                    logger.info(f"  ✅ {len(features)} decretos encontrados")
                    
                    if features:
                        # Mostrar exemplo
                        exemplo = features[0].get("properties", {})
                        logger.info(f"  📄 Exemplo: {exemplo}")
                        
                except Exception as e:
                    logger.warning(f"  ⚠️  Erro JSON: {str(e)}")
            else:
                logger.warning(f"  ❌ Erro {response.status_code}: {response.text[:200]}")
                
        except Exception as e:
            logger.warning(f"  ❌ Erro: {str(e)}")

if __name__ == "__main__":
    asyncio.run(testar_conder_completo())
