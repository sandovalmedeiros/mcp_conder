# testar_estrutura_conder.py
"""Descobre a estrutura real dos dados do CONDER"""

import asyncio
import requests
import logging
import xml.etree.ElementTree as ET

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def descobrir_tudo():
    """Descobre tudo sobre o serviço CONDER"""
    
    logger.info("🔍 DESCOBRINDO ESTRUTURA COMPLETA DO CONDER")
    logger.info("=" * 60)
    
    base_url = "https://mapas.conder.ba.gov.br/arcgis/services/Decretos/Decretos/MapServer/WFSServer"
    
    # Teste 1: GetCapabilities completo
    await analisar_capabilities(base_url)
    
    # Teste 2: DescribeFeatureType detalhado
    await analisar_feature_type(base_url)
    
    # Teste 3: GetFeature com dados reais
    await analisar_dados_reais(base_url)

async def analisar_capabilities(base_url):
    """Analisa GetCapabilities em detalhes"""
    
    logger.info("📋 ANALISANDO CAPABILITIES")
    logger.info("-" * 30)
    
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "GetCapabilities"
    }
    
    try:
        response = requests.get(base_url, params=params, timeout=30)
        
        if response.status_code == 200:
            logger.info("✅ GetCapabilities obtido")
            
            # Parse do XML
            root = ET.fromstring(response.text)
            
            # Procurar por FeatureTypeList
            for elem in root.iter():
                tag = elem.tag.split('}')[-1].lower()
                
                if 'featuretype' in tag and elem.text:
                    logger.info(f"🎯 FeatureType encontrado: {elem.text}")
                
                if 'name' in tag and elem.text and 'decretos' in elem.text.lower():
                    logger.info(f"📝 Nome relacionado a decretos: {elem.text}")
            
            # Salvar XML completo para análise
            with open('capabilities.xml', 'w', encoding='utf-8') as f:
                f.write(response.text)
            logger.info("💾 Capabilities salvo em capabilities.xml")
            
        else:
            logger.error(f"❌ Erro: {response.status_code}")
            
    except Exception as e:
        logger.error(f"❌ Erro: {str(e)}")

async def analisar_feature_type(base_url):
    """Analisa DescribeFeatureType em detalhes"""
    
    logger.info("\n📋 ANALISANDO FEATURE TYPES")
    logger.info("-" * 30)
    
    params = {
        "service": "WFS",
        "version": "2.0.0",
        "request": "DescribeFeatureType"
    }
    
    try:
        response = requests.get(base_url, params=params, timeout=30)
        
        if response.status_code == 200:
            logger.info("✅ DescribeFeatureType obtido")
            
            # Parse do XML
            root = ET.fromstring(response.text)
            
            # Extrair todos os elementos/campos
            campos = []
            for elem in root.iter():
                if 'element' in elem.tag.lower():
                    nome = elem.get('name')
                    tipo = elem.get('type')
                    if nome:
                        campos.append(f"{nome} ({tipo})")
            
            logger.info(f"📋 Campos encontrados ({len(campos)}):")
            for campo in campos:
                logger.info(f"  • {campo}")
            
            # Salvar XML
            with open('featuretype.xml', 'w', encoding='utf-8') as f:
                f.write(response.text)
            logger.info("💾 FeatureType salvo em featuretype.xml")
            
        else:
            logger.error(f"❌ Erro: {response.status_code}")
            
    except Exception as e:
        logger.error(f"❌ Erro: {str(e)}")

async def analisar_dados_reais(base_url):
    """Analisa dados reais retornados"""
    
    logger.info("\n📋 ANALISANDO DADOS REAIS")
    logger.info("-" * 30)
    
    # Tentar diferentes formatos de saída
    formatos = ["GML3", "GML2", "text/xml", "application/gml+xml"]
    
    for formato in formatos:
        logger.info(f"🔍 Testando formato: {formato}")
        
        params = {
            "service": "WFS",
            "version": "2.0.0",
            "request": "GetFeature",
            "typeName": "Decretos_da_Bahia",
            "outputFormat": formato,
            "maxFeatures": 2
        }
        
        try:
            response = requests.get(base_url, params=params, timeout=30)
            
            logger.info(f"  📡 Status: {response.status_code}")
            logger.info(f"  📄 Content-Type: {response.headers.get('content-type')}")
            logger.info(f"  📏 Tamanho: {len(response.text)} chars")
            
            if response.status_code == 200 and 'exception' not in response.text.lower():
                logger.info(f"  ✅ Formato {formato} funcionou!")
                
                # Salvar exemplo
                filename = f"exemplo_{formato.replace('/', '_')}.xml"
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(response.text)
                logger.info(f"  💾 Exemplo salvo em {filename}")
                
                # Parse rápido para ver estrutura
                try:
                    root = ET.fromstring(response.text)
                    
                    # Contar elementos
                    elementos_unicos = set()
                    valores_exemplo = {}
                    
                    for elem in root.iter():
                        tag = elem.tag.split('}')[-1]
                        elementos_unicos.add(tag)
                        
                        if elem.text and len(elem.text.strip()) > 0 and len(valores_exemplo) < 10:
                            valores_exemplo[tag] = elem.text[:100]
                    
                    logger.info(f"  📊 {len(elementos_unicos)} elementos únicos encontrados")
                    logger.info("  📋 Valores de exemplo:")
                    for tag, valor in valores_exemplo.items():
                        logger.info(f"    • {tag}: {valor}")
                        
                except ET.ParseError as e:
                    logger.warning(f"  ⚠️  Erro ao parsear XML: {str(e)}")
                
                break  # Se encontrou um formato que funciona, parar
                
            else:
                logger.warning(f"  ❌ Formato {formato} não funcionou")
                if len(response.text) < 500:
                    logger.info(f"  📄 Resposta: {response.text}")
                
        except Exception as e:
            logger.warning(f"  ❌ Erro com formato {formato}: {str(e)}")

if __name__ == "__main__":
    asyncio.run(descobrir_tudo())
