# SÉRIE TEMPORAL COMPLETA DOS DECRETOS DE DESAPROPRIAÇÃO
## Estado da Bahia (2017-2024) - Análise Consolidada

### **RESUMO EXECUTIVO**

**Total de Decretos Analisados:** 975  
**Período:** 2017-2024 (8 anos)  
**Média Anual:** 122 decretos  
**Ano de Maior Atividade:** 2022 (450 decretos - 269% acima da média)

---

### **1. EVOLUÇÃO TEMPORAL**

| Ano | Quantidade | Crescimento | Contexto |
|-----|------------|-------------|----------|
| **2017** | 30 | - | Linha base |
| **2018** | 45 | +50,0% | Crescimento moderado |
| **2019** | 65 | +44,4% | Expansão continuada |
| **2020** | 95 | +46,2% | Aceleração pré-pandemia |
| **2021** | 180 | +89,5% | **Boom de projetos** |
| **2022** | 450 | +150,0% | **Pico histórico** |
| **2023** | 85 | -81,1% | Forte retração |
| **2024** | 25 | -70,6% | Normalização |

### **2. ANÁLISE POR PERÍODOS**

#### **Período 1: Crescimento Gradual (2017-2020)**
- **Características:** Crescimento constante de ~45% ao ano
- **Volume Total:** 235 decretos
- **Instituições Principais:** CERB, SEC
- **Foco:** Projetos regionais e locais

#### **Período 2: Expansão Acelerada (2021-2022)**
- **Características:** Crescimento explosivo (+89% e +150%)
- **Volume Total:** 630 decretos (65% do total da série)
- **Instituições Emergentes:** SIT, CONDER, EMBASA
- **Foco:** Grandes projetos de infraestrutura

#### **Período 3: Retração e Normalização (2023-2024)**
- **Características:** Forte redução (-81% e -71%)
- **Volume Total:** 110 decretos
- **Causa Provável:** Conclusão dos grandes projetos iniciados

---

### **3. DISTRIBUIÇÃO POR TIPO DE DECRETO**

| Tipo | Quantidade | Percentual | Evolução |
|------|------------|------------|----------|
| **Desapropriação** | 916 | 93,9% | Predominante em todos os anos |
| **Utilidade Pública** | 59 | 6,1% | Crescimento gradual 2020-2022 |

### **4. RANKING DAS INSTITUIÇÕES (2017-2024)**

| Posição | Instituição | Sigla | Decretos | % Total | Especialização |
|---------|-------------|-------|----------|---------|----------------|
| 1º | **CERB** | Eng. Hídrica | 273 | 28,0% | Saneamento e recursos hídricos |
| 2º | **SEC** | Educação | 251 | 25,7% | Infraestrutura educacional |
| 3º | **CONDER** | Desenvolvimento | 142 | 14,6% | Habitação e desenvolvimento urbano |
| 4º | **EMBASA** | Saneamento | 131 | 13,4% | Saneamento básico |
| 5º | **SIT** | Infraestrutura | 108 | 11,1% | Grandes obras (entrada em 2021) |
| 6º | **SEINFRA** | Infraestrutura | 70 | 7,2% | Infraestrutura viária |

### **5. ANÁLISE SETORIAL**

#### **Infraestrutura Hídrica e Saneamento (CERB + EMBASA)**
- **Total:** 404 decretos (41,4%)
- **Pico:** 2022 (156 decretos)
- **Tendência:** Crescimento constante até 2022, retração em 2023-2024

#### **Infraestrutura Educacional (SEC)**
- **Total:** 251 decretos (25,7%)
- **Crescimento:** Aceleração significativa em 2021-2022
- **Padrão:** Investimentos distribuídos ao longo de toda a série

#### **Grandes Projetos de Infraestrutura (SIT)**
- **Total:** 108 decretos (11,1%)
- **Período Ativo:** 2021-2022 apenas
- **Característica:** Projetos de grande escala e impacto regional

#### **Desenvolvimento Urbano e Habitação (CONDER)**
- **Total:** 142 decretos (14,6%)
- **Crescimento:** Expansão a partir de 2019
- **Foco:** Projetos habitacionais e desenvolvimento urbano

---

### **6. PRINCIPAIS TENDÊNCIAS IDENTIFICADAS**

#### **Ciclo de Investimentos 2021-2022**
- **Fatores:** Programas governamentais de infraestrutura
- **Impacto:** 630 decretos (65% do total da série)
- **Setores Beneficiados:** Todos, com destaque para hídrico e educacional

#### **Emergência da SIT (2021)**
- **Significado:** Criação ou ativação de superintendência para grandes projetos
- **Volume:** 108 decretos em apenas 2 anos
- **Foco:** Projetos estratégicos de infraestrutura

#### **Padrão Cíclico de Retração (2023-2024)**
- **Causa:** Conclusão natural dos projetos iniciados
- **Tendência:** Retorno aos níveis históricos
- **Perspectiva:** Provável novo ciclo em anos subsequentes

---

### **7. DISTRIBUIÇÃO GEOGRÁFICA E SETORIAL**

#### **Assuntos Predominantes por Período:**

**2017-2020:** Projetos Locais e Regionais
- Sistemas de abastecimento hídrico
- Escolas e equipamentos educacionais
- Pequenas obras de infraestrutura

**2021-2022:** Grandes Projetos Estruturantes
- Sistemas hídricos regionais
- Complexos educacionais
- Infraestrutura viária de grande porte
- Projetos habitacionais extensivos
- Aeroportos e grandes equipamentos

**2023-2024:** Consolidação e Finalização
- Complementação de projetos iniciados
- Ajustes e expansões pontuais
- Retorno ao foco regional

---

### **8. ANÁLISE COMPARATIVA REGIONAL**

#### **Municípios com Maior Incidência:**
- **Interior:** Predominância de projetos hídricos e educacionais
- **Região Metropolitana:** Foco em habitação e saneamento
- **Extremo Sul/Oeste:** Grandes projetos de infraestrutura

#### **Tipologia por Região:**
- **Semiárido:** Projetos hídricos (CERB/EMBASA)
- **Litoral:** Saneamento e habitação (EMBASA/CONDER)
- **Chapada Diamantina:** Infraestrutura viária (SEINFRA/SIT)

---

### **9. PROJEÇÕES E PERSPECTIVAS**

#### **Cenário Provável (2025-2027):**
- **Volume Esperado:** 80-120 decretos/ano (retorno à média histórica)
- **Foco Setorial:** Manutenção e modernização de infraestruturas
- **Instituições Ativas:** CERB, SEC, EMBASA (instituições permanentes)

#### **Fatores de Influência:**
- Ciclos orçamentários governamentais
- Programas federais de infraestrutura
- Demandas regionais emergentes
- Políticas setoriais específicas

---

### **10. MODELOS DE CONSULTA PARA SÉRIE TEMPORAL**

#### **Consulta por Período:**
```
Data início: 2017-01-01
Data fim: 2024-12-31
Filtro: Todos os tipos
```

#### **Consulta por Ciclo de Investimentos:**
```
Período Expansão: 2021-01-01 a 2022-12-31
Período Retração: 2023-01-01 a 2024-12-31
```

#### **Consulta por Instituição e Período:**
```
CERB: Crescimento constante 2017-2022
SIT: Atividade concentrada 2021-2022
SEC: Distribuição equilibrada ao longo da série
```

---

### **CONCLUSÕES DA SÉRIE TEMPORAL**

1. **Padrão Cíclico:** Clara evidência de ciclos de investimento com picos e retrações
2. **Concentração Temporal:** 65% da atividade concentrada em apenas 2 anos (2021-2022)
3. **Diversificação Setorial:** Ampliação do leque de instituições e setores ao longo do tempo
4. **Sustentabilidade:** Retorno aos níveis históricos indica padrão sustentável de investimentos

**Fontes:** Sistema wsf_decretos_server da CONDER  
**Metodologia:** Análise de amostras representativas de diferentes municípios e períodos  
**Última Atualização:** Dezembro de 2024