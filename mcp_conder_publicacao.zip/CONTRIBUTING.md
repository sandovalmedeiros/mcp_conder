# Contribuindo com MCP CONDER

Agradecemos seu interesse em contribuir!

## Como contribuir
- Faça um fork do repositório
- Crie uma branch: `git checkout -b minha-feature`
- Commit suas mudanças: `git commit -m 'Minha contribuição'`
- Envie um push: `git push origin minha-feature`
- Crie um Pull Request
