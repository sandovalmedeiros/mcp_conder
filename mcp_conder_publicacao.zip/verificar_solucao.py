# verificar_solucao.py
"""Verificação rápida se a solução funcionou"""

import sys

def verificar_imports():
    """Verifica se todos os imports necessários funcionam"""
    print("🔍 VERIFICAÇÃO RÁPIDA DOS IMPORTS")
    print("=" * 40)
    
    imports_teste = [
        ("pydantic", "import pydantic"),
        ("fastmcp", "import fastmcp"),
        ("requests", "import requests"),
        ("wfs_decreto_tool", "from wfs_decreto_tool import wfs_decreto_search"),
    ]
    
    todos_ok = True
    
    for nome, codigo in imports_teste:
        try:
            exec(codigo)
            print(f"✅ {nome}")
        except ImportError as e:
            print(f"❌ {nome}: {e}")
            todos_ok = False
        except Exception as e:
            print(f"⚠️  {nome}: {e}")
    
    return todos_ok

def teste_servidor_basico():
    """Teste básico do servidor"""
    print("\n🧪 TESTE BÁSICO DO SERVIDOR")
    print("-" * 30)
    
    try:
        from fastmcp import FastMCP
        
        # Criar servidor de teste
        mcp = FastMCP("Teste Rápido")
        
        @mcp.tool
        async def teste(msg: str) -> dict:
            """Função de teste"""
            return {"resultado": f"OK: {msg}"}
        
        print("✅ Servidor FastMCP criado com sucesso")
        print("✅ Ferramenta registrada com sucesso")
        return True
        
    except Exception as e:
        print(f"❌ Erro no teste do servidor: {e}")
        return False

def main():
    """Função principal de verificação"""
    print("🎯 VERIFICAÇÃO COMPLETA")
    print("=" * 50)
    
    # Verificar imports
    imports_ok = verificar_imports()
    
    # Teste básico se imports estão OK
    servidor_ok = False
    if imports_ok:
        servidor_ok = teste_servidor_basico()
    
    # Resultado
    print("\n" + "=" * 50)
    print("📊 RESULTADO DA VERIFICAÇÃO")
    print("-" * 30)
    
    if imports_ok and servidor_ok:
        print("🎉 TUDO OK! Pronto para usar com Claude Desktop")
        print("\n💡 Próximos passos:")
        print("  1. Salvar mcp_stdio_server.py")
        print("  2. Configurar claude_desktop_config.json")
        print("  3. Reiniciar Claude Desktop")
        print("  4. Testar: 'Consulte o decreto 12345'")
    elif imports_ok:
        print("⚠️  Imports OK, mas servidor com problemas")
        print("🔧 Verifique o código do mcp_stdio_server.py")
    else:
        print("❌ Dependências ainda faltando")
        print("🔧 Execute: pip install pydantic fastmcp requests")
    
    return imports_ok and servidor_ok

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
