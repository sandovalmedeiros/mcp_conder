# teste_rapido_correcao.py
"""Teste rápido para verificar se a correção funcionou"""

import asyncio
import logging
import sys
from pathlib import Path

# Adicionar path para imports
sys.path.insert(0, str(Path(__file__).parent))

# Configurar logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

async def main():
    """Teste rápido das correções"""
    logger.info("🔧 TESTE RÁPIDO DA CORREÇÃO")
    logger.info("=" * 40)
    
    try:
        # Importar e criar servidor
        from mcp_server.server import create_mcp_server, list_registered_tools, test_tool_registration
        
        logger.info("📦 Criando servidor...")
        mcp = create_mcp_server()
        
        logger.info("📋 Testando listagem de ferramentas...")
        tools = list_registered_tools(mcp)
        
        logger.info(f"🔍 Tipo retornado: {type(tools)}")
        logger.info(f"📊 Conteúdo: {tools}")
        
        if isinstance(tools, dict):
            logger.info("✅ Tipo correto (dict) retornado!")
            
            for tool_name, tool_info in tools.items():
                logger.info(f"  🔧 {tool_name}:")
                if isinstance(tool_info, dict):
                    logger.info(f"    📝 Descrição: {tool_info.get('description', 'N/A')}")
                    logger.info(f"    ✅ Disponível: {tool_info.get('available', 'N/A')}")
                else:
                    logger.info(f"    📄 Valor: {tool_info}")
        else:
            logger.error(f"❌ Tipo incorreto: {type(tools)}")
        
        # Testar função de teste
        logger.info("\n🧪 Testando função de teste...")
        success = test_tool_registration(mcp)
        
        if success:
            logger.info("✅ Teste de registro: SUCESSO")
        else:
            logger.warning("⚠️  Teste de registro: FALHOU")
        
        # Testar chamadas diretas
        logger.info("\n🔬 Testando chamadas diretas das funções...")
        
        from wfs_decreto_tool import wfs_decreto_search, buscar_decretos_avancado
        
        # Teste 1
        result1 = await wfs_decreto_search("123", "2024")
        if result1.get("success"):
            logger.info("✅ wfs_decreto_search: OK")
        else:
            logger.error("❌ wfs_decreto_search: FALHOU")
        
        # Teste 2
        result2 = await buscar_decretos_avancado("Salvador")
        if result2.get("success"):
            logger.info("✅ buscar_decretos_avancado: OK")
        else:
            logger.error("❌ buscar_decretos_avancado: FALHOU")
        
        logger.info("\n" + "=" * 40)
        logger.info("🎉 TESTE RÁPIDO CONCLUÍDO!")
        
        return True
        
    except Exception as e:
        logger.error(f"❌ Erro no teste: {str(e)}")
        import traceback
        logger.error(f"📍 Traceback:\n{traceback.format_exc()}")
        return False

if __name__ == "__main__":
    asyncio.run(main())
