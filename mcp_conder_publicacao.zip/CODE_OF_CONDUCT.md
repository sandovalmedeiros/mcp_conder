# Código de Conduta

Este projeto segue o Código de Conduta para incentivar um ambiente aberto, acolhedor e respeitoso.

Respeite todos os participantes, evite linguagem ofensiva e contribua de maneira colaborativa.
